package com.hanu.courseman.software;

import com.hanu.courseman.software.config.SCCCourseManDerby;
import jda.modules.restfstool.RFSSoftware;

/**
 * @overview 
 *  Execute the Back end software from the generated components. 
 *  
 * @author Duc Minh Le (ducmle)
 *
 * @version 
 */
public class CourseManRFSRun {
  
  public static void main(String[] args) {
    Class scc = SCCCourseManDerby.class;
    
    new RFSSoftware(scc)
      .init()
      .run();
  }
}
