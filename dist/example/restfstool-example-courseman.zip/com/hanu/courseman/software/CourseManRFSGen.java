package com.hanu.courseman.software;

import com.hanu.courseman.software.config.SCCCourseManDerby;
import jda.modules.restfstool.RFSSoftware;

/**
 * The software generator for CourseManApp.
 * @author ducmle
 */
public class CourseManRFSGen {
    
    public static void main(String[] args) {
      Class scc = SCCCourseManDerby.class;

      new RFSSoftware(scc)
        .init()
        .generate()
        .run();
    }
}
