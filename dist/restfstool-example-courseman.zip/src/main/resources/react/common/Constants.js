const constants =  {
  host: "http://localhost:8080"
};
export default constants;